import requests
import pandas as pd

# api end point "football-get-all-countries" form Rapidapi
countries_url = "https://free-api-live-football-data.p.rapidapi.com/football-get-all-countries"
headers = {
    "X-RapidAPI-Key": "..................Enter API Key..................",
    "X-RapidAPI-Host": ".................Enter your Host................"
}

countries_url = "https://free-api-live-football-data.p.rapidapi.com/football-get-all-countries"
countries_response = requests.get(countries_url, headers=headers).json()

# country code or country_key of Spain or, here we can use different country name which we want
spain_ccode = None
for country in countries_response["response"]["countries"]:
    if country["name"].lower() == "spain":
        spain_ccode = country["ccode"]
        break

print("Country key for Spain:", spain_ccode)

#------------------

# api end point "football-get-all-leagues-with-countries" form Rapidapi
leagues_url = "https://free-api-live-football-data.p.rapidapi.com/football-get-all-leagues-with-countries"
leagues_response = requests.get(leagues_url, headers=headers).json()


def normalize(text):
    return text.lower().strip()

# Keywords to match LaLiga, LaLiga2...and also we can use Liga F
search_keywords = ["laliga"]

league_ids = []

for country in leagues_response["response"]["leagues"]:
    if country["ccode"] == "ESP":   # or we can use globally, if country["ccode"] == anycountry_ccode:
        for league in country["leagues"]:
            name = normalize(league.get("name", ""))
            localized_name = normalize(league.get("localizedName", ""))
            if any(keyword in name or keyword in localized_name for keyword in search_keywords):
                league_ids.append((league["id"], league["name"]))
                print(league["id"], league["name"])
        break

#-----------------

all_standings = []

# api end point "football-get-standing-all?leagueid=id" form Rapidapi
for league_id, league_name in league_ids:
    standings_url = f"https://free-api-live-football-data.p.rapidapi.com/football-get-standing-all?leagueid={league_id}"
    standings_response = requests.get(standings_url, headers=headers).json()

    for team in standings_response["response"]["standing"]:
        team_data = {
            "league_name": league_name,        
            "standing_team": team.get("name"),
            "standing_P": team.get("played"),
            "standing_W": team.get("wins"),
            "standing_D": team.get("draws"),
            "standing_L": team.get("losses"),
            "standing_F": team.get("scoresStr"),
            "standing_GD": team.get("goalConDiff"),
            "standing_PTS": team.get("pts"),
            "team_key":team.get("idx"),
            "league_key":team.get("id")
        }
        all_standings.append(team_data)

# dataframe
df = pd.DataFrame(all_standings)
df = df.sort_values(by=["league_name", "standing_PTS"], ascending=[True, False]).reset_index(drop=True)

df["standing_place"] = df.index + 1

df = df[[
    "standing_place", "league_name", "standing_team", "standing_P",
    "standing_W", "standing_D", "standing_L", "standing_F",
    "standing_GD", "standing_PTS", "team_key", "league_key"
]]

print(df)

df.to_excel("la_liga_standings_1.xlsx", index=False)
