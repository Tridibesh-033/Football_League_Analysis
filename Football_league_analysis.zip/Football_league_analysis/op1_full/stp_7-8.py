import pandas as pd

file_path = 'la_liga_standings_1.xlsx'
df = pd.read_excel(file_path)

df = df.sort_values('standing_place')

# top 4 teams for Champions League
champ_l = df.iloc[0:4].copy()
champ_l['qualification'] = 'Champions League'

# 5th team for Europa League
europa_l = df.iloc[4:5].copy()
europa_l['qualification'] = 'Europa League Group Stage'

# 6th for Conference League
confer_l = df.iloc[5:6].copy()
confer_l['qualification'] = 'Europa Conference League Qualifiers'

# take 3 teams from last for Relegation
releg = df.iloc[-3:].copy()
releg['qualification'] = 'Relegation'

# Combine all rows into single df
fdf = pd.concat([champ_l, europa_l, confer_l, releg])

fdf = fdf[['standing_team', 'standing_PTS', 'qualification']]
fdf.columns = ['Team', 'Points', 'Qualification']

fdf = fdf.reset_index(drop=True)

print(fdf)